//
//  Converter.h
//  TemperatureConverter
//
//  Created by Ian Piper on 10/12/2009.
//  Copyright 2009 Tellura Information Services Ltd. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface Converter : NSObject {
	float originalTemp; /**< model storage for the incoming temperature value */

}
/**
 The original temperature - may be Centigrade or Fahrenheit
 */
@property(readwrite) float originalTemp;

/**
 This method converts a Centigrade temperature 
 value to a Fahrenheit value
 */

- (float)convertCToF;

/**
 This method converts a Fahrenheit temperature 
 value to a Centigrade value
 */
- (float)convertFToC;

@end
