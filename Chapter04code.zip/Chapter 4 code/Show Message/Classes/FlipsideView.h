//
//  FlipsideView.h
//  Show Message
//
//  Created by Ian Piper on 17/08/2009.
//  Copyright Tellura Information Services 2009. All rights reserved.
//

@interface FlipsideView : UIView {
	
}

@end
