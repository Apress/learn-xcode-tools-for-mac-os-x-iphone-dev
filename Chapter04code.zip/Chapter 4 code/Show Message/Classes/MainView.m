//
//  MainView.m
//  Show Message
//
//  Created by Ian Piper on 17/08/2009.
//  Copyright Tellura Information Services 2009. All rights reserved.
//

#import "MainView.h"

@implementation MainView


- (id)initWithFrame:(CGRect)frame {
    if (self = [super initWithFrame:frame]) {
        // Initialization code
    }
    return self;
}


- (void)drawRect:(CGRect)rect {
    // Drawing code
}


- (void)dealloc {
    [super dealloc];
}


@end
