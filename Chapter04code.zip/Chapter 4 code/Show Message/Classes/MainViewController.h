//
//  MainViewController.h
//  Show Message
//
//  Created by Ian Piper on 17/08/2009.
//  Copyright Tellura Information Services 2009. All rights reserved.
//

#import "FlipsideViewController.h"

@interface MainViewController : UIViewController <FlipsideViewControllerDelegate> {
	IBOutlet UILabel *destinationTextField;
	IBOutlet UITextField *sourceTextField;
}

- (IBAction)showInfo;
- (IBAction)sayHello:(id)sender;
- (IBAction)textFieldFinishedWithKeyboard:(id)sender;
@end
