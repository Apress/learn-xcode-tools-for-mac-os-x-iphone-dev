//
//  Show_MessageAppDelegate.h
//  Show Message
//
//  Created by Ian Piper on 17/08/2009.
//  Copyright Tellura Information Services 2009. All rights reserved.
//

@class MainViewController;

@interface Show_MessageAppDelegate : NSObject <UIApplicationDelegate> {
    UIWindow *window;
    MainViewController *mainViewController;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic, retain) MainViewController *mainViewController;

@end

