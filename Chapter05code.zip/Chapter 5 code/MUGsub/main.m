//
//  main.m
//  MUGsub
//
//  Created by Ian Piper on 14/09/2009.
//  Copyright Tellura Information Services Ltd. 2009. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, char *argv[])
{
    return NSApplicationMain(argc,  (const char **) argv);
}
