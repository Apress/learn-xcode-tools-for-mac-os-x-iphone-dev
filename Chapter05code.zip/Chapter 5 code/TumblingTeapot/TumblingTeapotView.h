//
//  TumblingTeapotView.h
//  TumblingTeapot
//
//  Created by Ian Piper on 11/07/2009.
//  Copyright (c) 2009, Tellura Information Services Ltd. All rights reserved.
//

#import <ScreenSaver/ScreenSaver.h>
#import "TLOpenGLView.h"

@interface TumblingTeapotView : ScreenSaverView 
{
	TLOpenGLView *glView;
	GLfloat rotation;
	int displayList;	
}

- (void)startUpOpenGL;


@end
