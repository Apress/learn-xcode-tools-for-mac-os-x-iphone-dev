//
//  TumblingTeapotView.m
//  TumblingTeapot
//
//  Created by Ian Piper on 11/07/2009.
//  Copyright (c) 2009, Tellura Information Services Ltd. All rights reserved.
//

#import "TumblingTeapotView.h"
#import <GLUT/glut.h>

@implementation TumblingTeapotView

- (id)initWithFrame:(NSRect)frame isPreview:(BOOL)isPreview
{
	self = [super initWithFrame:frame isPreview:isPreview];
	if (self) {
		NSOpenGLPixelFormatAttribute attributes[] = {NSOpenGLPFAAccelerated, NSOpenGLPFADepthSize, 16, NSOpenGLPFAMinimumPolicy, NSOpenGLPFAClosestPolicy, 0};
		NSOpenGLPixelFormat *format;
		
		format = [[[NSOpenGLPixelFormat alloc] initWithAttributes:attributes] autorelease];
		glView = [[TLOpenGLView alloc] initWithFrame:NSZeroRect pixelFormat:format];
		if (!glView) {
			NSLog(@"Couldn't get OpenGL View going");
			[self autorelease];
			return nil;				
		}
		[self addSubview:glView];
		[self startUpOpenGL];
		[self setAnimationTimeInterval:1/30.0];
	}
	return self;
}

- (void)dealloc {
	[glView removeFromSuperview];
	[glView release];
	[super dealloc];
}

- (void)startUpOpenGL {
	NSLog(@"starting up OpenGL");
	[[glView openGLContext] makeCurrentContext];
	
	// configure the view
	glShadeModel(GL_SMOOTH);
	glEnable(GL_LIGHTING);
	glEnable(GL_DEPTH_TEST);
	
	// add ambient lighting
	GLfloat ambient[] = {0.2, 0.2, 0.2, 1.0};
	glLightModelfv(GL_LIGHT_MODEL_AMBIENT, ambient);
	
	// initialise the light
	GLfloat diffuse[] = {1.0, 1.0, 1.0, 1.0};
	glLightfv(GL_LIGHT0, GL_DIFFUSE, diffuse);
	// turn light on
	glEnable(GL_LIGHT0);
	
	// set material properties under ambient light
	// These values for the mat array will give a 
	// dark purple colour to the teapot
	GLfloat mat[] = {0.9, 0.1, 0.7, 1.0};
	glMaterialfv(GL_FRONT, GL_AMBIENT, mat);
	// set material properties under diffuse light
	glMaterialfv(GL_FRONT, GL_DIFFUSE, mat);
	rotation = 0.0f;
}

-(void)setFrameSize:(NSSize)newSize {
	[super setFrameSize:newSize];
	[glView setFrameSize:newSize];
	[[glView openGLContext] makeCurrentContext];
	glViewport(0, 0, (GLsizei)newSize.width, (GLsizei)newSize.height);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	[[glView openGLContext] update];
}


- (void)startAnimation
{
    [super startAnimation];
}

- (void)stopAnimation
{
    [super stopAnimation];
}

- (void)drawRect:(NSRect)rect
{
	[super drawRect:rect];
	[[glView openGLContext] makeCurrentContext];
	// clear the background
	glClearColor(0.75, 0.75, 0.95, 0.0);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	// set the viewpoint
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	glRotatef( rotation, 1.0f, 1.0f, 0.0f );
	// put the light in place
	GLfloat lightPosition [] = {1.6, 1, 3, 0.0};
	glLightfv(GL_LIGHT0, GL_POSITION, lightPosition);
	
	if (!displayList) {
		displayList = glGenLists(1);
		glNewList(displayList, GL_COMPILE_AND_EXECUTE);
		// do the drawing
		glTranslatef(0, 0, 0);
		glutSolidTeapot(0.5);
		glEndList();
	} else {
		glCallList(displayList);
	}
	glFinish();							 
	
}


- (void)animateOneFrame
{
	rotation += 0.2f;
[self setNeedsDisplay:YES];}

- (BOOL)hasConfigureSheet
{
    return NO;
}

- (NSWindow*)configureSheet
{
    return nil;
}

@end
