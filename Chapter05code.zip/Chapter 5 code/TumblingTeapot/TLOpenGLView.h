//
//  TLOpenGLView.h
//  TumblingTeapot
//
//  Created by Ian Piper on 11/07/2009.
//  Copyright 2009 Tellura Information Services Ltd. All rights reserved.
//

#import <Cocoa/Cocoa.h>


@interface TLOpenGLView : NSOpenGLView {

}

@end
