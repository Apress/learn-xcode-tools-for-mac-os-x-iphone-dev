//
//  Browser_PalAppDelegate.h
//  Browser Pal
//
//  Created by Ian Piper on 11/09/2009.
//  Copyright 2009 Tellura Information Services Ltd.. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface Browser_PalAppDelegate : NSObject <NSApplicationDelegate> {
    NSWindow *window;
}

@property (assign) IBOutlet NSWindow *window;

@end
