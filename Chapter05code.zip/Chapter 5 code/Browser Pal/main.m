//
//  main.m
//  Browser Pal
//
//  Created by Ian Piper on 11/09/2009.
//  Copyright 2009 Tellura Information Services Ltd.. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, char *argv[])
{
    return NSApplicationMain(argc,  (const char **) argv);
}
