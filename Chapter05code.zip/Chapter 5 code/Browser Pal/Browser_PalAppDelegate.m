//
//  Browser_PalAppDelegate.m
//  Browser Pal
//
//  Created by Ian Piper on 11/09/2009.
//  Copyright 2009 Tellura Information Services Ltd.. All rights reserved.
//

#import "Browser_PalAppDelegate.h"

@implementation Browser_PalAppDelegate

@synthesize window;

- (void)applicationDidFinishLaunching:(NSNotification *)aNotification {
	// Insert code here to initialize your application 
}

@end
