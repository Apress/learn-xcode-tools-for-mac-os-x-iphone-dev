//
//  My_First_ProjectAppDelegate.m
//  My First Project
//
//  Created by Ian Piper on 10/12/2009.
//  Copyright 2009 Tellura Information Services Ltd. All rights reserved.
//

#import "My_First_ProjectAppDelegate.h"

@implementation My_First_ProjectAppDelegate

@synthesize window;

- (void)applicationDidFinishLaunching:(NSNotification *)aNotification {
	// Insert code here to initialize your application 
	NSLog(@”Application has initialized”);
}

@end
