//
//  My_First_ProjectAppDelegate.h
//  My First Project
//
//  Created by Ian Piper on 10/12/2009.
//  Copyright 2009 Tellura Information Services Ltd. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface My_First_ProjectAppDelegate : NSObject <NSApplicationDelegate> {
    NSWindow *window;
}

@property (assign) IBOutlet NSWindow *window;

@end
