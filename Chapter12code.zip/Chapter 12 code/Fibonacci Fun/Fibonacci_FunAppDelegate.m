//
//  Fibonacci_FunAppDelegate.m
//  Fibonacci Fun
//
//  Created by Ian Piper on 03/11/2009.
//  Copyright 2009 Tellura Information Services Ltd.. All rights reserved.
//

#import "Fibonacci_FunAppDelegate.h"

@implementation Fibonacci_FunAppDelegate

@synthesize window;

- (void)applicationDidFinishLaunching:(NSNotification *)aNotification {
	// Insert code here to initialize your application 
}

-(IBAction)startCalculation:(id)sender {
	NSAutoreleasePool *fibPool = [[NSAutoreleasePool alloc] init];
	NSString *outputString;
	outputString = @"1: ";
	// Note to readers: in Chapter 12 you will set the number of iterations
	// around this loop to various figures in order to load the application
	// to differing degrees
	for (int x=1; x < 200; x++) {
		long long int fibValues[90];
		fibValues[0] = 0;
		fibValues[1] = 1;
		for (int i=2; i < 90; i++) {			
			fibValues[i] = fibValues[i-2] + fibValues[i-1];
			NSString *thisFibString;
			thisFibString = [[NSString alloc] initWithFormat:@"%lli, ",fibValues[i]];
			outputString = [outputString stringByAppendingFormat:@"%@", thisFibString];
			// we're done with thisFibString now, so release
			[thisFibString release];
		}
		outputString = [outputString stringByAppendingFormat:@"\n\n%i: ", x+1];
		[outputField setStringValue:outputString];
	}
	[fibPool drain];
}

@end
