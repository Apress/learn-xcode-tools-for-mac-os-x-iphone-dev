//
//  Fibonacci_FunAppDelegate.h
//  Fibonacci Fun
//
//  Created by Ian Piper on 03/11/2009.
//  Copyright 2009 Tellura Information Services Ltd.. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface Fibonacci_FunAppDelegate : NSObject <NSApplicationDelegate> {
	NSWindow *window;
	IBOutlet NSTextField *outputField;
}

@property (assign) IBOutlet NSWindow *window;

- (IBAction)startCalculation:(id)sender;

@end
