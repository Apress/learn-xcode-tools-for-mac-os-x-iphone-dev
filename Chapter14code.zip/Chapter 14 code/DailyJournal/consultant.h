//
//  consultant.h
//  DailyJournal
//
//  Created by Ian Piper on 17/10/2009.
//  Copyright 2009 Tellura Information Services Ltd. All rights reserved.
//

#import <CoreData/CoreData.h>


@interface consultant :  NSManagedObject  
{
}

@property (nonatomic, retain) NSString * consultantOfficePhone;
@property (nonatomic, retain) NSString * consultantStreetAddress;
@property (nonatomic, retain) NSString * consultantMobilePhone;
@property (nonatomic, retain) NSString * consultantLastName;
@property (nonatomic, retain) NSString * consultantFirstName;
@property (nonatomic, retain) NSSet* entriesForConsultant;
@property (readonly) NSString *fullName;

@end


@interface consultant (CoreDataGeneratedAccessors)
- (void)addEntriesForConsultantObject:(NSManagedObject *)value;
- (void)removeEntriesForConsultantObject:(NSManagedObject *)value;
- (void)addEntriesForConsultant:(NSSet *)value;
- (void)removeEntriesForConsultant:(NSSet *)value;

@end

