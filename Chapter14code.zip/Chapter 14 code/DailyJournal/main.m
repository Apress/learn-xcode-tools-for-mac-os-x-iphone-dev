//
//  main.m
//  DailyJournal
//
//  Created by Ian Piper on 17/10/2009.
//  Copyright Tellura Information Services Ltd 2009. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, char *argv[])
{
    return NSApplicationMain(argc,  (const char **) argv);
}
