//
//  HelloController.m
//  Hello World
//
//  Created by Ian Piper on 26/06/2009.
//  Copyright 2009 Tellura Information Services Ltd.. All rights reserved.
//

#import "HelloController.h"


@implementation HelloController

- (IBAction)sayHello:(id)sender {
	[destinationTextField setStringValue:[sourceTextField stringValue]];
}


@end
