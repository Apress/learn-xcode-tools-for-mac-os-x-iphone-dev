//
//  main.m
//  Hello World
//
//  Created by Ian Piper on 28/06/2009.
//  Copyright Tellura Information Services Ltd 2009. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, char *argv[])
{
    return NSApplicationMain(argc,  (const char **) argv);
}
