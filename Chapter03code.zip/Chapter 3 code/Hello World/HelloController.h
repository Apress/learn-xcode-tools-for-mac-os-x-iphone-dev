//
//  HelloController.h
//  Hello World
//
//  Created by Ian Piper on 28/06/2009.
//  Copyright 2009 Tellura Information Services Ltd. All rights reserved.
//

#import <Cocoa/Cocoa.h>


@interface HelloController : NSObject {
  IBOutlet NSTextField *destinationTextField;
	IBOutlet NSTextField *sourceTextField;
}

- (IBAction)sayHello:(id)sender;

@end
