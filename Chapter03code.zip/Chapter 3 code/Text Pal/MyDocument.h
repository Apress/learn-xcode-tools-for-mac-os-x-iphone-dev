//
//  MyDocument.h
//  Text Pal
//
//  Created by Ian Piper on 31/08/2009.
//  Copyright 2009 Tellura Information Services Ltd.. All rights reserved.
//


#import <Cocoa/Cocoa.h>

@interface MyDocument : NSDocument
{
	IBOutlet NSTextView *textView;
	NSAttributedString *string;
}

@property (retain) NSTextView *textView;
@property (retain) NSAttributedString *string;

@end
