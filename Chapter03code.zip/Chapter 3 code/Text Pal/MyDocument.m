//
//  MyDocument.m
//  Text Pal
//
//  Created by Ian Piper on 31/08/2009.
//  Copyright 2009 Tellura Information Services Ltd.. All rights reserved.
//

#import "MyDocument.h"

@implementation MyDocument

@synthesize textView;
@synthesize string;

- (id)init {
    self = [super init];
    if (self) {
    }
    return self;
}

- (NSString *)windowNibName {
    return @"MyDocument";
}

- (void)windowControllerDidLoadNib:(NSWindowController *) aController
{
	[super windowControllerDidLoadNib:aController];
	if (self.string != nil) {
	[[textView textStorage] setAttributedString:self.string];

	}
}

- (NSData *)dataOfType:(NSString *)typeName error:(NSError **)outError {
	NSData *data;
	self.string = textView.textStorage;	
	data = [NSArchiver archivedDataWithRootObject:self.string];
	return data;	
}

- (BOOL)readFromData:(NSData *)data ofType:(NSString *)typeName error:(NSError **)outError {
	NSAttributedString *tempString = [NSUnarchiver unarchiveObjectWithData: data];
	self.string = tempString;
	return YES;    
}


@end
