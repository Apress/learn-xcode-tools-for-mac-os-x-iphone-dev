// 
//  consultant.m
//  DailyJournal
//
//  Created by Ian Piper on 17/10/2009.
//  Copyright 2009 Tellura Information Services Ltd. All rights reserved.
//

#import "consultant.h"

// Comment added to Notebook copy of project. I think this is 
// the most relevant comment so I'll opt to keep this one

@implementation consultant 

@dynamic consultantOfficePhone;
@dynamic consultantStreetAddress;
@dynamic consultantMobilePhone;
@dynamic consultantLastName;
@dynamic consultantFirstName;
@dynamic entriesForConsultant;

- (NSString *)fullName {
	NSString *firstName = self.consultantFirstName;
	NSString *lastName = self.consultantLastName;
	if ((firstName) && (lastName)) {
		return [NSString stringWithFormat:@"%@ %@", firstName, lastName];
	}
	if (firstName) {
		return firstName;
	}
	if (lastName)    {
		return lastName;
	}
	// we get to here if neither firstName nor lastName is set
	NSString *noName = @"No name";
	return noName;
}

+ (NSSet *)keyPathsForValuesAffectingFullName {
	return [NSSet setWithObjects:@"consultantFirstName", @"consultantLastName", nil];
}


@end
