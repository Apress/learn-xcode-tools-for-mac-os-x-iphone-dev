//
//  ColorPalAppDelegate.m
//  ColorPal
//
//  Created by Ian Piper on 03/10/2009.
//  Copyright 2009 Tellura Information Services Ltd. All rights reserved.
//

#import "ColorPalAppDelegate.h"

@implementation ColorPalAppDelegate

@synthesize window;

- (void)applicationDidFinishLaunching:(NSNotification *)aNotification {
	// Insert code here to initialize your application 
}

@synthesize redIntValue;
@synthesize greenIntValue;
@synthesize blueIntValue;
@synthesize alphaFloatValue;

- (void)awakeFromNib {
	[self setValue:[NSNumber numberWithInt:51] forKey:@"redIntValue"];
	[self setValue:[NSNumber numberWithInt:102] forKey:@"greenIntValue"];
	[self setValue:[NSNumber numberWithInt:153] forKey:@"blueIntValue"];
	[self setValue:[NSNumber numberWithFloat:1.0] forKey:@"alphaFloatValue"];
	[self updateColorWell];	
}

- (IBAction)setNewColor:(id)sender {
	[self updateColorWell];
}

- (void)updateColorWell {
  NSColor *theColor = [NSColor colorWithCalibratedRed:((float)redIntValue/255) 
																								green:((float)greenIntValue/255) 
																								 blue:((float)blueIntValue/255) 
																								alpha:(alphaFloatValue)];
	[colorWell setColor:theColor];
}


@end
