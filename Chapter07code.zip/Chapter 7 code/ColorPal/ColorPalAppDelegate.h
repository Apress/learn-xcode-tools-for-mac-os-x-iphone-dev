//
//  ColorPalAppDelegate.h
//  ColorPal
//
//  Created by Ian Piper on 03/10/2009.
//  Copyright 2009 Tellura Information Services Ltd. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface ColorPalAppDelegate : NSObject <NSApplicationDelegate> {
    NSWindow *window;
  int redIntValue;
	int greenIntValue;
	int blueIntValue;
	float alphaFloatValue;
	IBOutlet NSColorWell *colorWell;
}

@property (assign) IBOutlet NSWindow *window;
@property(readwrite, assign) int redIntValue;
@property(readwrite, assign) int greenIntValue;
@property(readwrite, assign) int blueIntValue;
@property(readwrite, assign) float alphaFloatValue;

- (IBAction)setNewColor:(id)sender;
- (void)updateColorWell;

@end
