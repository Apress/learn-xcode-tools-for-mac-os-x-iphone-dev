//
//  TemperatureConverterAppDelegate.m
//  TemperatureConverter
//
//  Created by Ian Piper on 05/10/2009.
//  Copyright 2009 Tellura Information Services Ltd. All rights reserved.
//

#import "TemperatureConverterAppDelegate.h"

@implementation TemperatureConverterAppDelegate

@synthesize window;

- (void)applicationDidFinishLaunching:(NSNotification *)aNotification {
	// Insert code here to initialize your application 
}

- (void)awakeFromNib {
	fahrenheitField.floatValue = 32.0;
	centigradeField.floatValue = 0.0;
	tempConverter = Converter.new;
}

- (IBAction)convertTemperature:(id)sender {
	float temperatureF = fahrenheitField.floatValue;
	float temperatureC = centigradeField.floatValue;
	if(sender == fahrenheitField) {
		tempConverter.originalTemp = temperatureF;
		temperatureC = tempConverter.convertFToC;
		centigradeField.floatValue = temperatureC;
	} else if (sender == centigradeField) {
		tempConverter.originalTemp = temperatureC;
		 temperatureF = tempConverter.convertCToF;
		fahrenheitField.floatValue = temperatureF;
	}
}

@end
