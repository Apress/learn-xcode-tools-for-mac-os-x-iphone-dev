//
//  TemperatureConverterAppDelegate.h
//  TemperatureConverter
//
//  Created by Ian Piper on 05/10/2009.
//  Copyright 2009 Tellura Information Services Ltd. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "Converter.h"

@interface TemperatureConverterAppDelegate : NSObject <NSApplicationDelegate> {
    NSWindow *window;
	IBOutlet NSTextField *centigradeField;
	IBOutlet NSTextField *fahrenheitField;
	Converter *tempConverter;
}

@property (assign) IBOutlet NSWindow *window;

- (IBAction)convertTemperature:(id)sender;

@end
