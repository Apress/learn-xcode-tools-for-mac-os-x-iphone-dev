//
//  TCTests.h
//  TemperatureConverter
//
//  Created by Ian Piper on 25/10/2009.
//  Copyright 2009 Tellura Information Services Ltd. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>
#import "Converter.h"

@interface TCTests : SenTestCase {
	Converter *testTempConverter;
}



@end
