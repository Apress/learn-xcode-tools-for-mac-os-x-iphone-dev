//
//  TCTests.m
//  TemperatureConverter
//
//  Created by Ian Piper on 25/10/2009.
//  Copyright 2009 Tellura Information Services Ltd. All rights reserved.
//

#import "TCTests.h"

@implementation TCTests

- (void) setUp {
	testTempConverter = Converter.new;	
}

- (void) tearDown {
	[testTempConverter release];	
}

- (void)test25ShouldConvertTo77 {	
	[testTempConverter setValue:[NSNumber numberWithFloat:25.0] forKey:@"originalTemp"];	
	NSNumber *newTemperatureInF = [NSNumber numberWithFloat:(float)[testTempConverter convertCToF]];	
	STAssertEquals(77.0f, [newTemperatureInF floatValue], @"Expecting 77.0; we got %f", [newTemperatureInF floatValue]);
}

- (void)test100CShouldNotConvertTo100F {	
	[testTempConverter setValue:[NSNumber numberWithFloat:100.0] forKey:@"originalTemp"];	
	NSNumber *newTemperatureInF = [NSNumber numberWithFloat:(float)[testTempConverter convertCToF]];	
	STAssertFalse(100.0f==[newTemperatureInF floatValue], @"Result should be %f, not 100.0F", [newTemperatureInF floatValue]);
}

- (void)test98_6CShouldConvertTo37C {
	[testTempConverter setValue:[NSNumber numberWithFloat:98.6] forKey:@"originalTemp"];
	NSNumber *newTemperatureInC = [NSNumber numberWithFloat:(float)[testTempConverter convertFToC]];
	STAssertEquals(37.0f, [newTemperatureInC floatValue], @"Expecting 37.0; we got %f", [newTemperatureInC floatValue]);
}

- (void)testTemperatureAsWordShouldReturnZero {
	NSString *inputString = [NSString stringWithFormat:@"twenty"];
	[testTempConverter setValue:[NSNumber 
							numberWithFloat:[inputString floatValue]] 
											 forKey:@"originalTemp"];	
	NSNumber *newTemperatureInF = [NSNumber numberWithFloat:(float)[testTempConverter convertCToF]];	
	STAssertEquals(32.0f, [newTemperatureInF floatValue], @"Expecting 32.0; we got %f", [newTemperatureInF floatValue]);
}

- (void)testVeryLargeNumberShouldReturnInf {
	[testTempConverter setValue:[NSNumber numberWithFloat:1000000000000000000000000000000000000000.0] forKey:@"originalTemp"];
	NSNumber *newTemperatureInF = [NSNumber numberWithFloat:(float)[testTempConverter convertCToF]];
	NSString *newTemperatureString = [newTemperatureInF stringValue];
	NSString *testString = [NSString stringWithFormat:@"inf"];
	STAssertEqualObjects(testString, newTemperatureString, @"Expecting %@ and we got %@", testString, newTemperatureString);
}

@end
