//
//  Converter.m
//  TemperatureConverter
//
//  Created by Ian Piper on 05/10/2009.
//  Copyright 2009 Tellura Information Services Ltd. All rights reserved.
//

#import "Converter.h"

/**
 Implementation for Converter Model class
 */
@implementation Converter

@synthesize originalTemp;

/**
 The method takes a float value for the original temperature in Centigrade,
 applies a conversion function on that value and returns the resulting Fahrenheit
 temperature value, also as a float
*/
- (float)convertCToF {
	return ((self.originalTemp * 1.8) + 32.0);
}
/**
 The method takes a float value for the original temperature in Fahrenheit,
 applies a conversion function on that value and returns the resulting Centigrade 
 temperature value, also as a float
 */
- (float)convertFToC {
	return ((self.originalTemp - 32.0) / 1.8);	
}

@end
