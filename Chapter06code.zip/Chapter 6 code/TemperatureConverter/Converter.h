//
//  Converter.h
//  TemperatureConverter
//
//  Created by Ian Piper on 10/12/2009.
//  Copyright 2009 Tellura Information Services Ltd. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface Converter : NSObject {
	float originalTemp;
}

@property(readwrite) float originalTemp;

- (float)convertCToF;
- (float)convertFToC;

@end
