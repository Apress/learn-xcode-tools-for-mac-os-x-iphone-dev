//
//  Converter.m
//  TemperatureConverter
//
//  Created by Ian Piper on 10/12/2009.
//  Copyright 2009 Tellura Information Services Ltd. All rights reserved.
//

#import "Converter.h"

@implementation Converter

@synthesize originalTemp;

- (float)convertCToF {
	return ((self.originalTemp * 1.8) + 32.0);
}
- (float)convertFToC {
	return ((self.originalTemp - 32.0) / 1.8);
}
@end
